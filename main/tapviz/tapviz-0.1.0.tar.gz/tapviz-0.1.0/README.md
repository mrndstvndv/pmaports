# tapviz

`tapviz` is a Hyprland plugin for postmarketOS phones. It draws Android-like
circles for touchscreen contacts and, optionally, a small top-right status
label containing the latest touch phase, active finger count, and stable
ID-keyed rows of touch coordinates and optional movement metrics.

The plugin observes Hyprland's cancellable touch event bus without cancelling
or otherwise consuming the touch sequence. Applications continue to receive
normal touch input.

## Compatibility

This targets Hyprland `0.56.x` and uses internal rendering and touch-event APIs.
Build it against the exact Hyprland headers and commit that will load it. A
plugin built for a different Hyprland ABI can crash the compositor.

The plugin does not use function trampolines, so it does not depend on the
x86_64-only function-hook mechanism. It should still be rebuilt for every
Hyprland ABI change, including on ARM64 phones.

## Build

Install the matching Hyprland development headers, Lua 5.5 development headers,
and dependencies, then run:

```sh
make                 # build tapviz.so
make install         # install to ~/.local/lib/hyprland/plugins/
make activate        # replace a loaded copy and reload Hyprland config
```

`make doctor` checks the `pkg-config` dependencies and reports the detected
Hyprland/Lua versions. The normal setup has `hyprland.pc` available through
`pkg-config`; set `PKG_CONFIG_PATH` if the matching development files are in a
custom prefix. `make activate` is the convenient edit-build-test loop, while
`make load` and `make unload` are also available.

The Makefile does not download or clone dependencies. Hyprland plugins use
Hyprland's internal headers, so Hyprland, Hyprutils, and the other development
packages must come from one ABI-matched installation. Vendoring a random
Hyprutils checkout would make that more fragile rather than fixing it.

With `hyprpm`, use this directory as a plugin repository. The included
`hyprpm.toml` builds `tapviz.so`.

## Lua configuration

The plugin registers its values under `plugin:tapviz:*`, so current Hyprland
Lua configuration can use:

```lua
-- Load this before setting plugin values when loading manually.
-- hl.plugin.load("/absolute/path/to/tapviz.so")

hl.config({
    plugin = {
        tapviz = {
            enabled = true,
            show_text = true,
            show_metrics = true,
            show_path = true,
            show_trail = true,
            path_width = 4,
            trail_width = 2,
            path_dot_radius = 4,
            path_color = 0xAAFFFFFF,
            trail_color = 0x66FFFFFF,
            radius = 28,
            outline_width = 3,
            fade_time_ms = 260,
            fill_color = 0x55FFFFFF,
            outline_color = 0xCCFFFFFF,
            text_duration_ms = 1000,
            text_fade_ms = 180,
            text_size = 17,
            text_padding = 12,
            text_color = 0xFFFFFFFF,
            text_background = 0xCC000000,
            font_family = "Sans",
        },
    },
})
```

Colors use Hyprland's `0xAARRGGBB` format. The swipe path starts at the
initial touch position, ends at the live position, and draws endpoint dots.
With `show_trail`, a faint sampled polyline shows the actual route taken.
With `show_metrics`, each row also shows displacement (`dx`, `dy`), traveled
distance (`d`), smoothed speed (`v`, logical pixels/second), direction angle
(`a`, degrees), and elapsed time.

The plugin also exposes Lua helpers and a detailed `tapviz.touch_metrics`
event for gesture experiments or logging.

```lua
-- These require the plugin to be loaded.
hl.bind("SUPER + SHIFT + T", function()
    hl.plugin.tapviz.toggle()
end)

hl.bind("SUPER + SHIFT + C", function()
    hl.plugin.tapviz.clear()
end)
```

For optional Lua consumers, every touch emits the custom event
`tapviz.touch` with these arguments:

```lua
hl.on("tapviz.touch", function(phase, id, x, y, active_fingers)
    print(phase, id, x, y, active_fingers)
end)

-- Detailed per-contact data for gesture experiments:
-- phase, id, x, y, active_fingers, start_x, start_y, dx, dy, angle,
-- distance, speed, peak_speed, duration_ms
hl.on("tapviz.touch_metrics", function(phase, id, x, y, active_fingers, startX, startY, dx, dy, angle, distance, speed, peakSpeed, durationMs)
    print(id, dx, dy, distance, speed, peakSpeed, durationMs)
end)
```

Touch motion is intentionally rate-limited only for the text label. The
circles and the Lua event receive every touch motion event.
