#define WLR_USE_UNSTABLE

#include <algorithm>
#include <cairo.h>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <deque>
#include <format>
#include <numbers>
#include <string>
#include <string_view>
#include <stdexcept>
#include <unordered_map>
#include <utility>
#include <vector>

#include <hyprland/src/plugins/PluginAPI.hpp>
#include <hyprland/src/config/values/types/BoolValue.hpp>
#include <hyprland/src/config/values/types/ColorValue.hpp>
#include <hyprland/src/config/values/types/IntValue.hpp>
#include <hyprland/src/config/values/types/StringValue.hpp>
#include <hyprland/src/desktop/state/FocusState.hpp>
#include <hyprland/src/event/EventBus.hpp>
#include <hyprland/src/helpers/Color.hpp>
#include <hyprland/src/helpers/time/Time.hpp>
#include <hyprland/src/output/Monitor.hpp>
#include <hyprland/src/render/Renderer.hpp>
#include <hyprland/src/render/pass/RectPassElement.hpp>
#include <hyprland/src/render/pass/TexPassElement.hpp>
#include <hyprland/src/state/MonitorState.hpp>

extern "C" {
#include <lua.h>
#include <lauxlib.h>
}

namespace {

using TouchEvent = Event::CEventBus::CCustomEvent;
using TouchArgs  = TouchEvent::ValidVariant;

HANDLE PHANDLE = nullptr;

struct SConfig {
    SP<Config::Values::CBoolValue>   enabled;
    SP<Config::Values::CBoolValue>   showText;
    SP<Config::Values::CBoolValue>   showMetrics;
    SP<Config::Values::CBoolValue>   showPath;
    SP<Config::Values::CBoolValue>   showTrail;
    SP<Config::Values::CIntValue>    pathWidth;
    SP<Config::Values::CIntValue>    trailWidth;
    SP<Config::Values::CIntValue>    pathDotRadius;
    SP<Config::Values::CColorValue>  pathColor;
    SP<Config::Values::CColorValue>  trailColor;
    SP<Config::Values::CIntValue>    radius;
    SP<Config::Values::CIntValue>    outlineWidth;
    SP<Config::Values::CIntValue>    fadeTimeMs;
    SP<Config::Values::CColorValue>  fillColor;
    SP<Config::Values::CColorValue>  outlineColor;
    SP<Config::Values::CIntValue>    textDurationMs;
    SP<Config::Values::CIntValue>    textFadeMs;
    SP<Config::Values::CIntValue>    textSize;
    SP<Config::Values::CIntValue>    textPadding;
    SP<Config::Values::CColorValue>  textColor;
    SP<Config::Values::CColorValue>  textBackground;
    SP<Config::Values::CStringValue> fontFamily;
} g_config;

struct STouchPoint {
    Vector2D              startPosition;
    Vector2D              position;
    Vector2D              previousPosition;
    PHLMONITORREF         monitor;
    std::deque<Vector2D>  pathSamples;
    SP<Render::ITexture>  pathTexture;
    CBox                  pathBox;
    CBox                  pathDamage;
    float                 pathScale = 0.F;
    bool                  pathRendered = false;
    bool                  active = true;
    double                distance = 0.0;
    double                speed = 0.0;
    double                peakSpeed = 0.0;
    Time::steady_tp       startedAt;
    Time::steady_tp       lastMotionAt;
    Time::steady_tp       releasedAt;
};

struct SLastTouch {
    bool           present = false;
    int32_t        id      = 0;
    Vector2D       position;
    PHLMONITORREF  monitor;
    std::string    phase;
    std::string    text;
    Time::steady_tp eventAt;
    Time::steady_tp textUpdatedAt;
    bool           textUpdateInitialized = false;
    bool           textDirty              = true;
} g_lastTouch;

std::unordered_map<int32_t, STouchPoint> g_touches;
std::vector<CHyprSignalListener>        g_listeners;
SP<TouchEvent>                          g_touchEvent;
SP<TouchEvent>                          g_touchMetricsEvent;

SP<Render::ITexture> g_textTexture;
std::string         g_cachedText;
std::string         g_cachedFont;
Config::INTEGER     g_cachedTextSize  = -1;
Config::INTEGER     g_cachedTextColor = -1;
float               g_cachedTextScale = -1.F;

bool g_runtimeEnabled = true;
bool g_wasVisible     = false;
bool g_textRendered   = false;
CBox g_textDamage;

constexpr auto TEXT_UPDATE_INTERVAL = std::chrono::milliseconds(50);
constexpr double PATH_SAMPLE_DISTANCE = 4.0;
constexpr size_t MAX_PATH_SAMPLES = 256;

bool enabled() {
    return g_runtimeEnabled && g_config.enabled->value();
}

CHyprColor colorValue(const SP<Config::Values::CColorValue>& value) {
    return CHyprColor(static_cast<uint64_t>(value->value()));
}

Config::INTEGER clampedRadius() {
    return std::clamp<Config::INTEGER>(g_config.radius->value(), 1, 512);
}

Config::INTEGER clampedOutlineWidth() {
    return std::clamp<Config::INTEGER>(g_config.outlineWidth->value(), 0, clampedRadius());
}

Config::INTEGER clampedFadeTime() {
    return std::max<Config::INTEGER>(0, g_config.fadeTimeMs->value());
}

Config::INTEGER clampedPathWidth() {
    return std::clamp<Config::INTEGER>(g_config.pathWidth->value(), 1, 64);
}

Config::INTEGER clampedTrailWidth() {
    return std::clamp<Config::INTEGER>(g_config.trailWidth->value(), 1, 64);
}

Config::INTEGER clampedPathDotRadius() {
    return std::clamp<Config::INTEGER>(g_config.pathDotRadius->value(), 1, 64);
}

void damage(const CBox& box) {
    if (!g_pHyprRenderer || box.w <= 0 || box.h <= 0)
        return;

    g_pHyprRenderer->damageBox(box);
}

void damageAllMonitors() {
    if (!g_pHyprRenderer)
        return;

    for (const auto& monitor : State::monitorState()->monitors()) {
        if (monitor)
            g_pHyprRenderer->damageMonitor(monitor);
    }
}

CBox touchDamageBox(const STouchPoint& touch) {
    const double radius = static_cast<double>(clampedRadius()) + 4.0;
    return {touch.position.x - radius, touch.position.y - radius, radius * 2.0, radius * 2.0};
}

void damageTouch(const STouchPoint& touch) {
    damage(touchDamageBox(touch));
}

CBox pathDamageBox(const STouchPoint& touch) {
    double minX = std::min(touch.startPosition.x, touch.position.x);
    double minY = std::min(touch.startPosition.y, touch.position.y);
    double maxX = std::max(touch.startPosition.x, touch.position.x);
    double maxY = std::max(touch.startPosition.y, touch.position.y);
    if (g_config.showTrail->value()) {
        for (const auto& sample : touch.pathSamples) {
            minX = std::min(minX, sample.x);
            minY = std::min(minY, sample.y);
            maxX = std::max(maxX, sample.x);
            maxY = std::max(maxY, sample.y);
        }
    }

    const double lineHalfWidth = std::max(static_cast<double>(clampedPathWidth()), static_cast<double>(clampedTrailWidth())) / 2.0;
    const double extent = std::max(lineHalfWidth, static_cast<double>(clampedPathDotRadius())) + 4.0;
    return {minX - extent, minY - extent, maxX - minX + extent * 2.0, maxY - minY + extent * 2.0};
}

void damagePath(const STouchPoint& touch) {
    if (touch.pathRendered)
        damage(touch.pathDamage);
}

void damagePathGeometry(const STouchPoint& touch) {
    if (g_config.showPath->value())
        damage(pathDamageBox(touch));
}

void damageText() {
    if (g_textRendered)
        damage(g_textDamage);
}

int activeTouchCount() {
    int count = 0;
    for (const auto& [_, touch] : g_touches) {
        if (touch.active)
            ++count;
    }
    return count;
}

double displacementAngle(const Vector2D& displacement) {
    if (std::hypot(displacement.x, displacement.y) < 0.01)
        return 0.0;

    return std::atan2(displacement.y, displacement.x) * 180.0 / std::numbers::pi;
}

PHLMONITOR monitorForTouch(const ITouch::SDownEvent& event) {
    if (event.device && !event.device->m_boundOutput.empty()) {
        if (const auto monitor = State::monitorState()->query().name(event.device->m_boundOutput).run(); monitor)
            return monitor;
    }

    return Desktop::focusState()->monitor();
}

void emitTouchEvent(std::string_view phase, int32_t id, const Vector2D& position, Time::steady_tp now) {
    if (g_touchEvent) {
        std::vector<TouchArgs> args;
        args.emplace_back(std::string{phase});
        args.emplace_back(static_cast<int>(id));
        args.emplace_back(static_cast<double>(position.x));
        args.emplace_back(static_cast<double>(position.y));
        args.emplace_back(activeTouchCount());
        (void)g_touchEvent->emit(args);
    }

    if (!g_touchMetricsEvent)
        return;

    Vector2D startPosition = position;
    double   distance      = 0.0;
    double   speed         = 0.0;
    double   peakSpeed     = 0.0;
    double   durationMs    = 0.0;
    if (const auto it = g_touches.find(id); it != g_touches.end()) {
        const auto& touch = it->second;
        startPosition     = touch.startPosition;
        distance           = touch.distance;
        speed              = touch.speed;
        peakSpeed          = touch.peakSpeed;
        durationMs         = std::max(0.0, std::chrono::duration<double, std::milli>(now - touch.startedAt).count());
    }

    const auto delta = position - startPosition;
    const double angle = displacementAngle(delta);
    std::vector<TouchArgs> metrics;
    metrics.emplace_back(std::string{phase});
    metrics.emplace_back(static_cast<int>(id));
    metrics.emplace_back(static_cast<double>(position.x));
    metrics.emplace_back(static_cast<double>(position.y));
    metrics.emplace_back(activeTouchCount());
    metrics.emplace_back(static_cast<double>(startPosition.x));
    metrics.emplace_back(static_cast<double>(startPosition.y));
    metrics.emplace_back(static_cast<double>(delta.x));
    metrics.emplace_back(static_cast<double>(delta.y));
    metrics.emplace_back(angle);
    metrics.emplace_back(distance);
    metrics.emplace_back(speed);
    metrics.emplace_back(peakSpeed);
    metrics.emplace_back(durationMs);
    (void)g_touchMetricsEvent->emit(metrics);
}

std::string formatTouchStatus(std::string_view phase, int32_t id, const Vector2D& position, Time::steady_tp now) {
    std::string text = std::format("touch {}  fingers:{}", phase, activeTouchCount());

    // Keep rows ordered by touch ID rather than putting the most recently
    // updated contact first. That way a moving finger does not make rows
    // change places on every update.
    std::vector<int32_t> rowIds;
    rowIds.reserve(g_touches.size() + 1);
    for (const auto& [touchId, touch] : g_touches) {
        if (touch.active)
            rowIds.emplace_back(touchId);
    }
    rowIds.emplace_back(id);
    std::sort(rowIds.begin(), rowIds.end());
    rowIds.erase(std::unique(rowIds.begin(), rowIds.end()), rowIds.end());

    for (const auto touchId : rowIds) {
        Vector2D rowPosition = position;
        const auto  it        = g_touches.find(touchId);
        if (it != g_touches.end())
            rowPosition = it->second.position;

        if (!g_config.showMetrics->value() || it == g_touches.end()) {
            text += std::format("\nid:{}  x:{:.0f} y:{:.0f}", touchId, rowPosition.x, rowPosition.y);
            continue;
        }

        const auto& touch = it->second;
        const auto  delta = touch.position - touch.startPosition;
        const double ageMs = std::max(0.0, std::chrono::duration<double, std::milli>(now - touch.startedAt).count());
        text += std::format("\nid:{}  x:{:.0f} y:{:.0f}  dx:{:+.0f} dy:{:+.0f}  d:{:.0f} v:{:.0f}  a:{:+.0f} t:{:.0f}ms", touchId, rowPosition.x, rowPosition.y,
                            delta.x, delta.y, touch.distance, touch.speed, displacementAngle(delta), ageMs);
    }

    return text;
}

void updateLastTouch(std::string_view phase, int32_t id, const Vector2D& position, PHLMONITOR monitor, Time::steady_tp now, bool forceText) {
    g_lastTouch.present  = true;
    g_lastTouch.id       = id;
    g_lastTouch.position = position;
    g_lastTouch.monitor  = monitor;
    g_lastTouch.phase    = phase;
    g_lastTouch.eventAt  = now;

    const bool updateText = forceText || !g_lastTouch.textUpdateInitialized ||
        now - g_lastTouch.textUpdatedAt >= TEXT_UPDATE_INTERVAL;

    if (!updateText)
        return;

    damageText();

    g_lastTouch.text = formatTouchStatus(phase, id, position, now);
    g_lastTouch.textUpdatedAt        = now;
    g_lastTouch.textUpdateInitialized = true;
    g_lastTouch.textDirty             = true;
}

void updateTouchMotion(STouchPoint& touch, const Vector2D& position, Time::steady_tp now) {
    const Vector2D delta = position - touch.position;
    const double stepDistance = std::hypot(delta.x, delta.y);
    const double seconds = std::chrono::duration<double>(now - touch.lastMotionAt).count();

    touch.previousPosition = touch.position;
    touch.position         = position;
    touch.distance        += stepDistance;

    if (touch.pathSamples.empty() || std::hypot(position.x - touch.pathSamples.back().x, position.y - touch.pathSamples.back().y) >= PATH_SAMPLE_DISTANCE)
        touch.pathSamples.emplace_back(position);
    else
        touch.pathSamples.back() = position;
    if (touch.pathSamples.size() > MAX_PATH_SAMPLES)
        touch.pathSamples.pop_front();

    if (seconds > 0.0) {
        const double instantaneousSpeed = stepDistance / seconds;
        if (touch.speed <= 0.0)
            touch.speed = instantaneousSpeed;
        else
            touch.speed = touch.speed * 0.65 + instantaneousSpeed * 0.35;
        touch.peakSpeed = std::max(touch.peakSpeed, touch.speed);
    }

    touch.lastMotionAt = now;
}

void onTouchDown(ITouch::SDownEvent event, Event::SCallbackInfo&) {
    if (!enabled())
        return;

    const auto monitor = monitorForTouch(event);
    if (!monitor)
        return;

    const auto now = Time::steadyNow();
    if (const auto old = g_touches.find(event.touchID); old != g_touches.end()) {
        damageTouch(old->second);
        damagePath(old->second);
        g_touches.erase(old);
    }

    const Vector2D globalPosition = monitor->m_position + (event.pos * monitor->m_size);
    auto&          touch          = g_touches[event.touchID];
    touch.startPosition           = globalPosition;
    touch.position                = globalPosition;
    touch.previousPosition        = globalPosition;
    touch.monitor                 = monitor;
    touch.pathSamples.clear();
    touch.pathTexture.reset();
    touch.pathBox                 = {};
    touch.pathDamage              = {};
    touch.pathScale               = 0.F;
    touch.pathRendered            = false;
    touch.active                  = true;
    touch.distance                = 0.0;
    touch.speed                   = 0.0;
    touch.peakSpeed               = 0.0;
    touch.startedAt               = now;
    touch.lastMotionAt            = now;
    touch.releasedAt              = {};

    damageTouch(touch);
    damagePathGeometry(touch);
    updateLastTouch("down", event.touchID, globalPosition, monitor, now, true);
    emitTouchEvent("down", event.touchID, globalPosition, now);
}

void onTouchMotion(ITouch::SMotionEvent event, Event::SCallbackInfo&) {
    if (!enabled())
        return;

    const auto it = g_touches.find(event.touchID);
    if (it == g_touches.end() || !it->second.active)
        return;

    auto& touch = it->second;
    damageTouch(touch);
    damagePath(touch);

    const auto monitor = touch.monitor.lock();
    if (!monitor) {
        g_touches.erase(it);
        return;
    }

    const auto now = Time::steadyNow();
    const Vector2D position = monitor->m_position + (event.pos * monitor->m_size);
    updateTouchMotion(touch, position, now);
    touch.pathTexture.reset();
    touch.pathBox      = {};
    touch.pathScale    = 0.F;
    touch.pathRendered = false;
    damageTouch(touch);
    damagePathGeometry(touch);

    updateLastTouch("move", event.touchID, touch.position, monitor, now, false);
    emitTouchEvent("move", event.touchID, touch.position, now);
}

void finishTouch(int32_t touchID, std::string_view phase) {
    if (!enabled())
        return;

    const auto it = g_touches.find(touchID);
    if (it == g_touches.end() || !it->second.active)
        return;

    auto& touch        = it->second;
    const auto monitor = touch.monitor.lock();
    if (!monitor) {
        g_touches.erase(it);
        return;
    }

    damageTouch(touch);
    damagePath(touch);
    touch.active     = false;
    touch.releasedAt = Time::steadyNow();
    damageTouch(touch);

    updateLastTouch(phase, touchID, touch.position, monitor, touch.releasedAt, true);
    emitTouchEvent(phase, touchID, touch.position, touch.releasedAt);
}

void onTouchUp(ITouch::SUpEvent event, Event::SCallbackInfo&) {
    finishTouch(event.touchID, "up");
}

void onTouchCancel(ITouch::SCancelEvent event, Event::SCallbackInfo&) {
    finishTouch(event.touchID, "cancel");
}

float touchOpacity(const STouchPoint& touch, Time::steady_tp now) {
    if (touch.active)
        return 1.F;

    const auto fadeTime = clampedFadeTime();
    if (fadeTime <= 0)
        return 0.F;

    const auto elapsed = std::chrono::duration<float, std::milli>(now - touch.releasedAt).count();
    return std::clamp(1.F - elapsed / static_cast<float>(fadeTime), 0.F, 1.F);
}

void addTouchCircle(PHLMONITOR monitor, const STouchPoint& touch, float opacity) {
    const float scale = std::max(0.01F, monitor->m_scale);
    const float radius = static_cast<float>(clampedRadius()) * scale;
    const float centerX = static_cast<float>((touch.position.x - monitor->m_position.x) * scale);
    const float centerY = static_cast<float>((touch.position.y - monitor->m_position.y) * scale);

    CBox outerBox{centerX - radius, centerY - radius, radius * 2.F, radius * 2.F};
    const int outerRound = static_cast<int>(std::round(radius));

    auto outline = colorValue(g_config.outlineColor);
    outline.a *= opacity;

    CRectPassElement::SRectData outlineData;
    outlineData.box            = outerBox;
    outlineData.color          = outline;
    outlineData.round          = outerRound;
    outlineData.roundingPower  = 2.F;
    g_pHyprRenderer->m_renderPass.add(makeUnique<CRectPassElement>(outlineData));

    const float innerRadius = std::max(0.F, radius - static_cast<float>(clampedOutlineWidth()) * scale);
    if (innerRadius <= 0.F)
        return;

    CBox innerBox{centerX - innerRadius, centerY - innerRadius, innerRadius * 2.F, innerRadius * 2.F};
    auto  fill = colorValue(g_config.fillColor);
    fill.a *= opacity;

    CRectPassElement::SRectData fillData;
    fillData.box            = innerBox;
    fillData.color           = fill;
    fillData.round           = static_cast<int>(std::round(innerRadius));
    fillData.roundingPower   = 2.F;
    g_pHyprRenderer->m_renderPass.add(makeUnique<CRectPassElement>(fillData));
}

bool ensurePathTexture(PHLMONITOR monitor, STouchPoint& touch) {
    if (!g_config.showPath->value() || !g_pHyprRenderer)
        return false;

    const float scale = std::max(0.01F, monitor->m_scale);
    if (touch.pathTexture && std::abs(touch.pathScale - scale) <= 0.001F)
        return true;

    touch.pathTexture.reset();
    touch.pathScale = scale;

    const Vector2D start = (touch.startPosition - monitor->m_position) * scale;
    const Vector2D end   = (touch.position - monitor->m_position) * scale;
    const bool directLine = std::hypot(end.x - start.x, end.y - start.y) >= 0.01;

    double minX = std::min(start.x, end.x);
    double minY = std::min(start.y, end.y);
    double maxX = std::max(start.x, end.x);
    double maxY = std::max(start.y, end.y);
    bool   hasTrail = false;
    if (g_config.showTrail->value()) {
        for (const auto& sample : touch.pathSamples) {
            const Vector2D local = (sample - monitor->m_position) * scale;
            minX = std::min(minX, local.x);
            minY = std::min(minY, local.y);
            maxX = std::max(maxX, local.x);
            maxY = std::max(maxY, local.y);
            hasTrail = hasTrail || std::hypot(local.x - start.x, local.y - start.y) >= 0.01;
        }
    }
    if (!directLine && !hasTrail)
        return false;

    const float lineWidth = std::max(1.F, static_cast<float>(clampedPathWidth()) * scale);
    const float trailWidth = std::max(1.F, static_cast<float>(clampedTrailWidth()) * scale);
    const float margin    = std::max(lineWidth, trailWidth) / 2.F + 1.F;
    const float left      = static_cast<float>(minX) - margin;
    const float top       = static_cast<float>(minY) - margin;
    const float right     = static_cast<float>(maxX) + margin;
    const float bottom    = static_cast<float>(maxY) + margin;
    const int   width     = std::max(1, static_cast<int>(std::ceil(right - left)));
    const int   height    = std::max(1, static_cast<int>(std::ceil(bottom - top)));

    touch.pathBox = {left, top, static_cast<float>(width), static_cast<float>(height)};

    auto* surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, width, height);
    if (!surface || cairo_surface_status(surface) != CAIRO_STATUS_SUCCESS) {
        if (surface)
            cairo_surface_destroy(surface);
        return false;
    }

    auto* context = cairo_create(surface);
    if (!context || cairo_status(context) != CAIRO_STATUS_SUCCESS) {
        if (context)
            cairo_destroy(context);
        cairo_surface_destroy(surface);
        return false;
    }

    cairo_set_operator(context, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgba(context, 0., 0., 0., 0.);
    cairo_paint(context);
    cairo_set_operator(context, CAIRO_OPERATOR_OVER);

    cairo_set_antialias(context, CAIRO_ANTIALIAS_BEST);
    cairo_set_line_cap(context, CAIRO_LINE_CAP_ROUND);

    if (g_config.showTrail->value()) {
        const auto trailColor = colorValue(g_config.trailColor);
        cairo_set_source_rgba(context, trailColor.r, trailColor.g, trailColor.b, trailColor.a);
        cairo_set_line_width(context, trailWidth);
        cairo_move_to(context, start.x - left, start.y - top);
        for (const auto& sample : touch.pathSamples) {
            const Vector2D local = (sample - monitor->m_position) * scale;
            cairo_line_to(context, local.x - left, local.y - top);
        }
        cairo_line_to(context, end.x - left, end.y - top);
        cairo_stroke(context);
    }

    if (directLine) {
        const auto color = colorValue(g_config.pathColor);
        cairo_set_source_rgba(context, color.r, color.g, color.b, color.a);
        cairo_set_line_width(context, lineWidth);
        cairo_move_to(context, start.x - left, start.y - top);
        cairo_line_to(context, end.x - left, end.y - top);
        cairo_stroke(context);
    }
    cairo_surface_flush(surface);

    touch.pathTexture = g_pHyprRenderer->createTexture(surface);
    cairo_destroy(context);
    cairo_surface_destroy(surface);
    return !!touch.pathTexture;
}

void addPathDot(PHLMONITOR monitor, const Vector2D& position, float opacity) {
    const float scale = std::max(0.01F, monitor->m_scale);
    const float radius = static_cast<float>(clampedPathDotRadius()) * scale;
    const float centerX = static_cast<float>((position.x - monitor->m_position.x) * scale);
    const float centerY = static_cast<float>((position.y - monitor->m_position.y) * scale);

    CRectPassElement::SRectData data;
    data.box            = {centerX - radius, centerY - radius, radius * 2.F, radius * 2.F};
    data.color          = colorValue(g_config.pathColor);
    data.color.a       *= opacity;
    data.round          = static_cast<int>(std::round(radius));
    data.roundingPower  = 2.F;
    g_pHyprRenderer->m_renderPass.add(makeUnique<CRectPassElement>(data));
}

void addSwipePath(PHLMONITOR monitor, STouchPoint& touch, float opacity) {
    if (!g_config.showPath->value())
        return;

    touch.pathDamage   = pathDamageBox(touch);
    touch.pathRendered = true;
    // Keep the path alive during the release fade and make the first path
    // visible even when the touch circle damaged a different region.
    damage(touch.pathDamage);

    if (ensurePathTexture(monitor, touch)) {
        CTexPassElement::SRenderData pathData;
        pathData.tex = touch.pathTexture;
        pathData.box = touch.pathBox;
        pathData.a   = opacity;
        g_pHyprRenderer->m_renderPass.add(makeUnique<CTexPassElement>(std::move(pathData)));
    }

    // The anchor and the live head make the direction obvious even for very
    // short swipes. The normal touch circle is drawn over the live head.
    addPathDot(monitor, touch.startPosition, opacity);
    addPathDot(monitor, touch.position, opacity);
}

bool textVisible(Time::steady_tp now) {
    if (!g_lastTouch.present || !g_config.showText->value())
        return false;

    const auto duration = std::max<Config::INTEGER>(0, g_config.textDurationMs->value());
    if (duration <= 0)
        return false;

    return now - g_lastTouch.eventAt < std::chrono::milliseconds(duration);
}

float textOpacity(Time::steady_tp now) {
    const auto duration = std::max<Config::INTEGER>(0, g_config.textDurationMs->value());
    const auto fade     = std::clamp<Config::INTEGER>(g_config.textFadeMs->value(), 0, duration);
    if (fade <= 0)
        return 1.F;

    const auto age       = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_lastTouch.eventAt).count();
    const auto fadeStart = duration - fade;
    if (age <= fadeStart)
        return 1.F;

    return std::clamp(static_cast<float>(duration - age) / static_cast<float>(fade), 0.F, 1.F);
}

CBox textBoxForMonitor(PHLMONITOR monitor) {
    const float scale   = std::max(0.01F, monitor->m_scale);
    const float padding = static_cast<float>(std::max<Config::INTEGER>(0, g_config.textPadding->value())) * scale;
    const auto  size    = g_textTexture->m_size;

    return {monitor->m_transformedSize.x - size.x - padding * 2.F, padding, size.x + padding * 2.F, size.y + padding * 2.F};
}

CBox textDamageBoxForMonitor(PHLMONITOR monitor, const CBox& pixelBox) {
    const float scale = std::max(0.01F, monitor->m_scale);
    return {monitor->m_position.x + pixelBox.x / scale, monitor->m_position.y + pixelBox.y / scale, pixelBox.w / scale, pixelBox.h / scale};
}

bool ensureTextTexture(PHLMONITOR monitor) {
    if (!g_lastTouch.present || g_lastTouch.text.empty())
        return false;

    const auto color     = g_config.textColor->value();
    const auto font      = g_config.fontFamily->value();
    const auto textSize  = g_config.textSize->value();
    const auto scale     = monitor->m_scale;
    const bool needsText = !g_textTexture || g_lastTouch.textDirty || g_cachedText != g_lastTouch.text || g_cachedFont != font ||
        g_cachedTextSize != textSize || g_cachedTextColor != color || std::abs(g_cachedTextScale - scale) > 0.001F;

    if (!needsText)
        return true;

    damageText();

    const int scaledTextSize = std::max(1, static_cast<int>(std::round(std::max<Config::INTEGER>(1, textSize) * scale)));
    const int padding         = std::max(0, static_cast<int>(g_config.textPadding->value() * scale));
    const int maxWidth        = std::max(1, static_cast<int>(monitor->m_transformedSize.x) - padding * 2);

    g_textTexture = g_pHyprRenderer->renderText(
        g_lastTouch.text,
        colorValue(g_config.textColor),
        scaledTextSize,
        false,
        font,
        maxWidth
    );

    if (!g_textTexture)
        return false;

    g_cachedText      = g_lastTouch.text;
    g_cachedFont      = font;
    g_cachedTextSize  = textSize;
    g_cachedTextColor = color;
    g_cachedTextScale = scale;
    g_lastTouch.textDirty = false;
    return true;
}

void addTextOverlay(PHLMONITOR monitor, Time::steady_tp now) {
    const auto textMonitor = g_lastTouch.monitor.lock();
    if (!textMonitor || textMonitor.get() != monitor.get() || !textVisible(now) || !ensureTextTexture(monitor))
        return;

    const float opacity = textOpacity(now);
    if (opacity <= 0.F)
        return;

    const float scale   = std::max(0.01F, monitor->m_scale);
    const float padding = static_cast<float>(std::max<Config::INTEGER>(0, g_config.textPadding->value())) * scale;
    const CBox  box     = textBoxForMonitor(monitor);
    const CBox  damageBoxGlobal = textDamageBoxForMonitor(monitor, box);

    g_textDamage   = damageBoxGlobal;
    g_textRendered = true;
    // Damage the label for the next frame. This is needed when the touch
    // itself only damaged a small area elsewhere on the monitor, and it also
    // keeps the label's fade animation updating.
    damage(damageBoxGlobal);

    auto background = colorValue(g_config.textBackground);
    background.a *= opacity;

    CRectPassElement::SRectData backgroundData;
    backgroundData.box            = box;
    backgroundData.color          = background;
    backgroundData.round          = static_cast<int>(std::round(std::min(padding, static_cast<float>(box.h) / 2.F)));
    backgroundData.roundingPower = 2.F;
    g_pHyprRenderer->m_renderPass.add(makeUnique<CRectPassElement>(backgroundData));

    CTexPassElement::SRenderData textData;
    textData.tex = g_textTexture;
    textData.box = {box.x + padding, box.y + padding, g_textTexture->m_size.x, g_textTexture->m_size.y};
    textData.a   = opacity;
    g_pHyprRenderer->m_renderPass.add(makeUnique<CTexPassElement>(std::move(textData)));
}

void clearVisualState();

void onRenderStage(eRenderStage stage) {
    if (stage != RENDER_LAST_MOMENT || !g_pHyprRenderer)
        return;

    const auto monitor = g_pHyprRenderer->m_renderData.pMonitor.lock();
    if (!monitor)
        return;

    if (!enabled()) {
        if (g_wasVisible || !g_touches.empty() || g_lastTouch.present)
            clearVisualState();
        return;
    }

    g_wasVisible = true;
    const auto now = Time::steadyNow();
    bool       needsAnotherFrame = false;

    for (auto it = g_touches.begin(); it != g_touches.end();) {
        auto& touch = it->second;
        if (!touch.monitor.lock()) {
            it = g_touches.erase(it);
            continue;
        }

        const float opacity = touchOpacity(touch, now);
        if (opacity <= 0.F) {
            damageTouch(touch);
            damagePath(touch);
            it = g_touches.erase(it);
            continue;
        }

        if (const auto touchMonitor = touch.monitor.lock(); touchMonitor && touchMonitor.get() == monitor.get()) {
            addSwipePath(monitor, touch, opacity);
            addTouchCircle(monitor, touch, opacity);
        }

        if (!touch.active) {
            damageTouch(touch);
            needsAnotherFrame = true;
        }

        ++it;
    }

    const auto textMonitor = g_lastTouch.monitor.lock();
    if (textVisible(now) && textMonitor && textMonitor.get() == monitor.get()) {
        addTextOverlay(monitor, now);
        needsAnotherFrame = true;
    } else if (!textVisible(now) && g_textRendered) {
        damageText();
        g_textRendered = false;
        g_textTexture.reset();
        g_lastTouch.textDirty = true;
    }

    if (needsAnotherFrame)
        monitor->scheduleFrame();
}

void clearVisualState() {
    damageAllMonitors();
    g_touches.clear();
    g_lastTouch = {};
    g_textTexture.reset();
    g_textRendered = false;
    g_textDamage = {};
    g_wasVisible = false;
}

int luaToggle(lua_State* L) {
    g_runtimeEnabled = !g_runtimeEnabled;
    if (!g_runtimeEnabled)
        clearVisualState();
    else
        damageAllMonitors();

    lua_pushboolean(L, g_runtimeEnabled);
    return 1;
}

int luaSetEnabled(lua_State* L) {
    if (!lua_isboolean(L, 1))
        return luaL_error(L, "tapviz.set_enabled expects a boolean");

    g_runtimeEnabled = lua_toboolean(L, 1);
    if (!g_runtimeEnabled)
        clearVisualState();
    else
        damageAllMonitors();

    return 0;
}

int luaClear(lua_State*) {
    clearVisualState();
    return 0;
}

void onConfigReloaded() {
    clearVisualState();

    // Lua recreates its event handler on every config reload. Re-registering
    // the event makes the new handler attach its custom-event listener while
    // preserving any hl.on("tapviz.touch", ...) subscriptions.
    if (g_touchEvent) {
        HyprlandAPI::removeEvent(PHANDLE, g_touchEvent->m_name);
        if (!HyprlandAPI::addEvent(PHANDLE, g_touchEvent))
            g_touchEvent.reset();
    }

    if (g_touchMetricsEvent) {
        HyprlandAPI::removeEvent(PHANDLE, g_touchMetricsEvent->m_name);
        if (!HyprlandAPI::addEvent(PHANDLE, g_touchMetricsEvent))
            g_touchMetricsEvent.reset();
    }
}

void registerConfigValues() {
    g_config.enabled = makeShared<Config::Values::CBoolValue>("plugin:tapviz:enabled", "Enable the tap visualizer", true);
    g_config.showText = makeShared<Config::Values::CBoolValue>("plugin:tapviz:show_text", "Show the latest touch information in the top-right corner", true);
    g_config.showMetrics = makeShared<Config::Values::CBoolValue>("plugin:tapviz:show_metrics", "Show movement metrics in touch rows", true);
    g_config.showPath = makeShared<Config::Values::CBoolValue>("plugin:tapviz:show_path", "Show a path from touch-down to the current position", true);
    g_config.showTrail = makeShared<Config::Values::CBoolValue>("plugin:tapviz:show_trail", "Show the sampled movement trail", true);
    g_config.pathWidth = makeShared<Config::Values::CIntValue>("plugin:tapviz:path_width", "Swipe path width in logical pixels", 4,
                                                               Config::Values::SIntValueOptions{.min = 1, .max = 64});
    g_config.trailWidth = makeShared<Config::Values::CIntValue>("plugin:tapviz:trail_width", "Sampled trail width in logical pixels", 2,
                                                                 Config::Values::SIntValueOptions{.min = 1, .max = 64});
    g_config.pathDotRadius = makeShared<Config::Values::CIntValue>("plugin:tapviz:path_dot_radius", "Swipe path endpoint radius in logical pixels", 4,
                                                                     Config::Values::SIntValueOptions{.min = 1, .max = 64});
    g_config.pathColor = makeShared<Config::Values::CColorValue>("plugin:tapviz:path_color", "Swipe path and endpoint color", 0xAAFFFFFF);
    g_config.trailColor = makeShared<Config::Values::CColorValue>("plugin:tapviz:trail_color", "Sampled movement trail color", 0x66FFFFFF);
    g_config.radius = makeShared<Config::Values::CIntValue>("plugin:tapviz:radius", "Touch indicator radius in logical pixels", 28,
                                                            Config::Values::SIntValueOptions{.min = 1, .max = 512});
    g_config.outlineWidth = makeShared<Config::Values::CIntValue>("plugin:tapviz:outline_width", "Touch indicator outline width", 3,
                                                                   Config::Values::SIntValueOptions{.min = 0, .max = 64});
    g_config.fadeTimeMs = makeShared<Config::Values::CIntValue>("plugin:tapviz:fade_time_ms", "Touch indicator fade time after release", 260,
                                                                Config::Values::SIntValueOptions{.min = 0, .max = 5000});
    g_config.fillColor = makeShared<Config::Values::CColorValue>("plugin:tapviz:fill_color", "Touch indicator fill color", 0x55FFFFFF);
    g_config.outlineColor = makeShared<Config::Values::CColorValue>("plugin:tapviz:outline_color", "Touch indicator outline color", 0xCCFFFFFF);
    g_config.textDurationMs = makeShared<Config::Values::CIntValue>("plugin:tapviz:text_duration_ms", "How long the touch text remains visible", 1000,
                                                                     Config::Values::SIntValueOptions{.min = 0, .max = 30000});
    g_config.textFadeMs = makeShared<Config::Values::CIntValue>("plugin:tapviz:text_fade_ms", "Touch text fade time", 180,
                                                                 Config::Values::SIntValueOptions{.min = 0, .max = 5000});
    g_config.textSize = makeShared<Config::Values::CIntValue>("plugin:tapviz:text_size", "Touch text size in logical pixels", 17,
                                                               Config::Values::SIntValueOptions{.min = 1, .max = 128});
    g_config.textPadding = makeShared<Config::Values::CIntValue>("plugin:tapviz:text_padding", "Padding around the touch text", 12,
                                                                  Config::Values::SIntValueOptions{.min = 0, .max = 128});
    g_config.textColor = makeShared<Config::Values::CColorValue>("plugin:tapviz:text_color", "Touch text color", 0xFFFFFFFF);
    g_config.textBackground = makeShared<Config::Values::CColorValue>("plugin:tapviz:text_background", "Touch text background color", 0xCC000000);
    g_config.fontFamily = makeShared<Config::Values::CStringValue>("plugin:tapviz:font_family", "Font used for touch text", "Sans");

    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.enabled);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.showText);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.showMetrics);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.showPath);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.showTrail);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.pathWidth);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.trailWidth);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.pathDotRadius);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.pathColor);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.trailColor);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.radius);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.outlineWidth);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.fadeTimeMs);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.fillColor);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.outlineColor);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textDurationMs);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textFadeMs);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textSize);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textPadding);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textColor);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.textBackground);
    HyprlandAPI::addConfigValueV2(PHANDLE, g_config.fontFamily);
}

void registerLuaEvent() {
    std::vector<TouchEvent::eType> types{
        TouchEvent::TYPE_STRING, // phase
        TouchEvent::TYPE_INT,    // touch id
        TouchEvent::TYPE_DOUBLE, // global x
        TouchEvent::TYPE_DOUBLE, // global y
        TouchEvent::TYPE_INT,    // active finger count
    };

    g_touchEvent = makeShared<TouchEvent>("tapviz.touch", std::move(types));
    if (!HyprlandAPI::addEvent(PHANDLE, g_touchEvent))
        g_touchEvent.reset();

    std::vector<TouchEvent::eType> metricTypes{
        TouchEvent::TYPE_STRING, // phase
        TouchEvent::TYPE_INT,    // touch id
        TouchEvent::TYPE_DOUBLE, // current x
        TouchEvent::TYPE_DOUBLE, // current y
        TouchEvent::TYPE_INT,    // active finger count
        TouchEvent::TYPE_DOUBLE, // start x
        TouchEvent::TYPE_DOUBLE, // start y
        TouchEvent::TYPE_DOUBLE, // displacement x
        TouchEvent::TYPE_DOUBLE, // displacement y
        TouchEvent::TYPE_DOUBLE, // displacement angle in degrees
        TouchEvent::TYPE_DOUBLE, // traveled distance
        TouchEvent::TYPE_DOUBLE, // current speed in logical px/s
        TouchEvent::TYPE_DOUBLE, // peak speed in logical px/s
        TouchEvent::TYPE_DOUBLE, // duration in milliseconds
    };

    g_touchMetricsEvent = makeShared<TouchEvent>("tapviz.touch_metrics", std::move(metricTypes));
    if (!HyprlandAPI::addEvent(PHANDLE, g_touchMetricsEvent))
        g_touchMetricsEvent.reset();
}

} // namespace

// Do NOT change this function.
APICALL EXPORT std::string PLUGIN_API_VERSION() {
    return HYPRLAND_API_VERSION;
}

APICALL EXPORT PLUGIN_DESCRIPTION_INFO PLUGIN_INIT(HANDLE handle) {
    PHANDLE = handle;

    const std::string compositorHash = __hyprland_api_get_hash();
    const std::string clientHash     = __hyprland_api_get_client_hash();
    if (compositorHash != clientHash) {
        HyprlandAPI::addNotification(PHANDLE, "[tapviz] Header/compositor version mismatch", CHyprColor{1.F, 0.2F, 0.2F, 1.F}, 5000);
        throw std::runtime_error("tapviz: Hyprland version mismatch");
    }

    registerConfigValues();
    registerLuaEvent();
    HyprlandAPI::addLuaFunction(PHANDLE, "tapviz", "toggle", luaToggle);
    HyprlandAPI::addLuaFunction(PHANDLE, "tapviz", "set_enabled", luaSetEnabled);
    HyprlandAPI::addLuaFunction(PHANDLE, "tapviz", "clear", luaClear);

    g_listeners.reserve(6);
    g_listeners.emplace_back(Event::bus()->m_events.input.touch.down.listen(onTouchDown));
    g_listeners.emplace_back(Event::bus()->m_events.input.touch.motion.listen(onTouchMotion));
    g_listeners.emplace_back(Event::bus()->m_events.input.touch.up.listen(onTouchUp));
    g_listeners.emplace_back(Event::bus()->m_events.input.touch.cancel.listen(onTouchCancel));
    g_listeners.emplace_back(Event::bus()->m_events.render.stage.listen(onRenderStage));
    g_listeners.emplace_back(Event::bus()->m_events.config.reloaded.listen(onConfigReloaded));

    // Apply values supplied by hyprland.lua after the plugin registers them.
    HyprlandAPI::reloadConfig();

    return {"tapviz", "Android-like touchscreen tap indicators for Hyprland", "waynav", "0.1.0"};
}

APICALL EXPORT void PLUGIN_EXIT() {
    clearVisualState();
    g_listeners.clear();

    if (g_touchEvent)
        HyprlandAPI::removeEvent(PHANDLE, "tapviz.touch");
    if (g_touchMetricsEvent)
        HyprlandAPI::removeEvent(PHANDLE, "tapviz.touch_metrics");
    g_touchEvent.reset();
    g_touchMetricsEvent.reset();
    g_textTexture.reset();
}
